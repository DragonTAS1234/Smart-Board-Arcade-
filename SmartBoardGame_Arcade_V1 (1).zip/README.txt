
SMART BOARD ARCADE - v1

1. Install the APK on your Android tablet (to be added manually).
2. Run the Godot game from the tablet.
3. Open controller.html on a phone browser and connect to the tablet's IP.
4. Use joystick to move, and 'Strike' to dash.

This is the base arcade version. Realistic physics and scoring coming next!
